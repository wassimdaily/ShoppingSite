<?php

$conn = mysqli_connect("localhost","id7296420_root","TRuMeh8r*r","id7296420_shoping");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
 
?>